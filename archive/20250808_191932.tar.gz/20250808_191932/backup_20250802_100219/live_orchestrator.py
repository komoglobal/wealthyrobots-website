import os
import sys
import time
import json
import threading
from datetime import datetime, timedelta
from dotenv import load_dotenv

# Import your existing agents
try:
    from content_agent import ContentAgent
except:
    ContentAgent = None
try:
    from ad_placement_agent import AdAgent
except:
    try:
        from ad_agent import AdAgent
    except:
        AdAgent = None
try:
    from analytics_agent import AnalyticsAgent
except:
    AnalyticsAgent = None
try:
    from social_media_agent import SocialMediaAgent
except:
    SocialMediaAgent = None

from ultimate_ceo_agent import UltimateAutonomousCEO
from live_config_manager import LiveConfigManager

load_dotenv()

class LiveAutonomousOrchestrator:
    def __init__(self):
        print("🚀 INITIALIZING LIVE-CONTROLLED AUTONOMOUS COMPANY...")
        
        # Live configuration system
        self.live_config = LiveConfigManager()
        self.setup_config_callbacks()
        
        # Initialize agents (with fallbacks)
        self.content_agent = ContentAgent() if ContentAgent else None
        self.ad_agent = AdAgent() if AdAgent else None
        self.analytics_agent = AnalyticsAgent() if AnalyticsAgent else None
        self.social_agent = SocialMediaAgent() if SocialMediaAgent else None
        self.ceo = UltimateAutonomousCEO()
        
        # Agent tracking
        self.agent_status = {
            'CEO': {'last_run': 'Never', 'status': 'idle'},
            'CONTENT': {'last_run': 'Never', 'status': 'idle'},
            'ADS': {'last_run': 'Never', 'status': 'idle'},
            'ANALYTICS': {'last_run': 'Never', 'status': 'idle'},
            'SOCIAL': {'last_run': 'Never', 'status': 'idle'}
        }
        
        # Performance metrics
        self.metrics = {
            'total_content': 0,
            'total_revenue': 0.0,
            'content_revenue': 0.0,
            'active_campaigns': 0,
            'cycle_count': 0
        }
        
        # Live control state
        self.running = True
        self.paused = False
        self.manual_mode = False
        
        print("✅ Live-Controlled Orchestrator Initialized!")
        print("🎮 You can now edit settings in real-time!")
        
    def setup_config_callbacks(self):
        """Set up callbacks for live configuration changes"""
        def on_config_change(old_config, new_config):
            # Check for budget changes
            old_budget = old_config.get('ceo_settings', {}).get('daily_budget', 100)
            new_budget = new_config.get('ceo_settings', {}).get('daily_budget', 100)
            if old_budget != new_budget:
                print(f"💰 LIVE UPDATE: Daily budget changed from ${old_budget} to ${new_budget}")
            
            # Check for risk tolerance changes
            old_risk = old_config.get('ceo_settings', {}).get('risk_tolerance', 5)
            new_risk = new_config.get('ceo_settings', {}).get('risk_tolerance', 5)
            if old_risk != new_risk:
                print(f"🎯 LIVE UPDATE: Risk tolerance changed from {old_risk} to {new_risk}")
        
        self.live_config.register_callback('orchestrator', on_config_change)
    
    def check_live_controls(self):
        """Check live control settings and respond"""
        # Emergency stop
        if self.live_config.get('strategy_overrides.emergency_stop'):
            print("🚨 EMERGENCY STOP ACTIVATED!")
            self.running = False
            return False
        
        # Pause/resume
        pause_state = self.live_config.get('strategy_overrides.pause_automation')
        if pause_state and not self.paused:
            print("⏸️ AUTOMATION PAUSED by live control")
            self.paused = True
        elif not pause_state and self.paused:
            print("▶️ AUTOMATION RESUMED by live control")
            self.paused = False
        
        # Manual mode
        manual_state = self.live_config.get('strategy_overrides.manual_mode')
        if manual_state != self.manual_mode:
            self.manual_mode = manual_state
            print(f"🎮 Manual mode: {'ENABLED' if manual_state else 'DISABLED'}")
        
        return True
    
    def get_enabled_agents(self):
        """Get list of currently enabled agents from config"""
        return self.live_config.get('automation_settings.enabled_agents', 
                                 ['content', 'social', 'analytics', 'ceo'])
    
    def get_cycle_interval(self):
        """Get current cycle interval in seconds"""
        minutes = self.live_config.get('automation_settings.cycle_interval_minutes', 60)
        return minutes * 60
    
    def display_live_status(self):
        """Display live status with current configuration"""
        print("\n" + "="*60)
        print("🏢 LIVE-CONTROLLED AUTONOMOUS COMPANY STATUS")
        print("="*60)
        
        # Live configuration status
        print("🎮 LIVE CONTROL STATUS:")
        print(f"  ⚡ Running: {'YES' if self.running else 'NO'}")
        print(f"  ⏸️ Paused: {'YES' if self.paused else 'NO'}")
        print(f"  🎮 Manual Mode: {'YES' if self.manual_mode else 'NO'}")
        print(f"  ⏰ Cycle Interval: {self.live_config.get('automation_settings.cycle_interval_minutes', 60)} minutes")
        
        # CEO Settings
        print("💰 CEO SETTINGS:")
        print(f"  💸 Daily Budget: ${self.live_config.get('ceo_settings.daily_budget', 100)}")
        print(f"  🎯 Risk Level: {self.live_config.get('ceo_settings.risk_tolerance', 5)}/10")
        print(f"  🔥 Aggression: {self.live_config.get('ceo_settings.aggression_level', 5)}/10")
        
        # Agent status
        print("🤖 AGENT STATUS:")
        enabled_agents = self.get_enabled_agents()
        for agent_name, status in self.agent_status.items():
            agent_available = "✅" if self.get_agent_by_name(agent_name) else "❌"
            enabled_status = "🟢" if agent_name.lower() in enabled_agents else "🔴"
            print(f"  {agent_available} {enabled_status} {agent_name}: {status['status']} (Last: {status['last_run']})")
        
        # Performance metrics
        print("📊 PERFORMANCE METRICS:")
        print(f"  📝 Total Content Pieces: {self.metrics['total_content']}")
        print(f"  💰 Total Revenue: ${self.metrics['total_revenue']:.2f}")
        print(f"  🔄 Automation Cycles: {self.metrics['cycle_count']}")
        print("="*60)
    
    def get_agent_by_name(self, agent_name):
        """Get agent instance by name"""
        agent_map = {
            'CEO': self.ceo,
            'CONTENT': self.content_agent,
            'ADS': self.ad_agent,
            'ANALYTICS': self.analytics_agent,
            'SOCIAL': self.social_agent
        }
        return agent_map.get(agent_name.upper())
    
    def run_agent_if_enabled(self, agent_name, agent_function):
        """Run agent only if enabled in live config"""
        enabled_agents = self.get_enabled_agents()
        
        if agent_name.lower() not in enabled_agents:
            print(f"⏭️ {agent_name} agent disabled in live config - skipping")
            return
        
        agent = self.get_agent_by_name(agent_name)
        if not agent:
            print(f"❌ {agent_name} agent not available - skipping")
            return
        
        print(f"🤖 Running {agent_name} Agent...")
        
        try:
            self.agent_status[agent_name.upper()]['status'] = 'running'
            result = agent_function()
            self.agent_status[agent_name.upper()]['status'] = 'idle'
            self.agent_status[agent_name.upper()]['last_run'] = datetime.now().strftime('%Y-%m-%d %H:%M')
            return result
        except Exception as e:
            print(f"❌ Error in {agent_name} agent: {e}")
            self.agent_status[agent_name.upper()]['status'] = 'error'
    
    def run_full_automation_cycle(self):
        """Run a complete automation cycle with live controls"""
        if self.paused:
            print("⏸️ Automation cycle skipped - system paused")
            return
        
        print(f"\n🚀 STARTING LIVE-CONTROLLED AUTOMATION CYCLE #{self.metrics['cycle_count'] + 1}")
        print("="*60)
        
        # Run agents based on live config
        self.run_agent_if_enabled('CEO', self.ceo.run_ultimate_ceo_cycle)
        
        if self.content_agent:
            self.run_agent_if_enabled('CONTENT', self.content_agent.create_content)
        
        if self.ad_agent:
            self.run_agent_if_enabled('ADS', self.ad_agent.place_ads)
        
        if self.analytics_agent:
            self.run_agent_if_enabled('ANALYTICS', self.analytics_agent.analyze_performance)
        
        if self.social_agent:
            self.run_agent_if_enabled('SOCIAL', self.social_agent.create_social_media_posts)
        
        # Update metrics
        self.metrics['cycle_count'] += 1
        
        print("✅ LIVE-CONTROLLED AUTOMATION CYCLE COMPLETE!")
        print("="*60)
    
    def run_manual_cycle(self):
        """Run manual control mode"""
        print("\n🎮 MANUAL MODE - Choose actions:")
        print("1. Run CEO Analysis")
        print("2. Create Content")
        print("3. Place Ads")
        print("4. Run Analytics")
        print("5. Social Media")
        print("6. Full Cycle")
        print("7. Exit Manual Mode")
        
        try:
            choice = input("Choice: ").strip()
            
            if choice == "1":
                self.run_agent_if_enabled('CEO', self.ceo.run_ultimate_ceo_cycle)
            elif choice == "2" and self.content_agent:
                self.run_agent_if_enabled('CONTENT', self.content_agent.create_content)
            elif choice == "3" and self.ad_agent:
                self.run_agent_if_enabled('ADS', self.ad_agent.place_ads)
            elif choice == "4" and self.analytics_agent:
                self.run_agent_if_enabled('ANALYTICS', self.analytics_agent.analyze_performance)
            elif choice == "5" and self.social_agent:
                self.run_agent_if_enabled('SOCIAL', self.social_agent.create_social_media_posts)
            elif choice == "6":
                self.run_full_automation_cycle()
            elif choice == "7":
                self.live_config.set('strategy_overrides.manual_mode', False)
            
        except KeyboardInterrupt:
            print("\n🎮 Exiting manual mode...")
            self.live_config.set('strategy_overrides.manual_mode', False)
    
    def run(self):
        """Main execution loop with live controls"""
        print("🚀 STARTING LIVE-CONTROLLED AUTONOMOUS COMPANY")
        print("🎮 Real-time editing enabled!")
        print("📝 Edit live_config.json to change settings instantly")
        print("🎮 Run: python3 live_control.py for interactive control")
        
        try:
            while self.running:
                # Check live control settings
                if not self.check_live_controls():
                    break
                
                # Display current status
                self.display_live_status()
                
                if self.manual_mode:
                    self.run_manual_cycle()
                elif not self.paused:
                    self.run_full_automation_cycle()
                    
                    # Wait for next cycle (respecting live config)
                    interval = self.get_cycle_interval()
                    print(f"⏰ Waiting {interval//60} minutes until next cycle...")
                    print("🎮 Edit live_config.json anytime to change settings!")
                    
                    # Sleep in chunks to check for live updates
                    for i in range(0, interval, 10):
                        if not self.check_live_controls():
                            break
                        time.sleep(min(10, interval - i))
                else:
                    # System paused - check every 10 seconds
                    time.sleep(10)
                    
        except KeyboardInterrupt:
            print("\n👋 Shutting down live-controlled automation...")
        
        finally:
            # Cleanup
            self.live_config.cleanup()
            print("🏁 Live-controlled autonomous company stopped.")

if __name__ == "__main__":
    print("🤖 WEALTHYROBOT LIVE-CONTROLLED AUTONOMOUS COMPANY")
    print("="*60)
    
    # Initialize and run live orchestrator
    orchestrator = LiveAutonomousOrchestrator()
    orchestrator.run()

    def run_claude_autonomous_cycle(self):
        """Run Claude's autonomous empire optimization cycle"""
        try:
            from claude_autonomous_coder import ClaudeAutonomousCoder
            
            print("🤖 Running Claude Autonomous Cycle...")
            claude = ClaudeAutonomousCoder()
            
            # Claude analyzes empire and takes autonomous action
            needs = claude.analyze_empire_needs()
            
            if needs.get('optimization_opportunities'):
                print(f"🎯 Claude found {len(needs['optimization_opportunities'])} optimization opportunities")
                
                # Claude can autonomously create solutions
                for opportunity in needs['optimization_opportunities'][:1]:  # Handle one per cycle
                    print(f"🛠️ Claude implementing: {opportunity}")
                    solution = claude.autonomous_problem_solving(f"Implement {opportunity}")
                    
            if needs.get('missing_agents') and len(needs['missing_agents']) > 0:
                # Claude creates missing agents autonomously
                missing_agent = needs['missing_agents'][0]
                print(f"🔨 Claude creating missing agent: {missing_agent}")
                claude.write_new_agent(missing_agent, f"Handles {missing_agent} for empire", ['automation'])
            
            return {'claude_cycle': 'completed', 'optimizations': len(needs.get('optimization_opportunities', []))}
            
        except Exception as e:
            print(f"❌ Claude cycle error: {e}")
            return {'claude_cycle': 'error', 'error': str(e)}


    def run_claude_full_autonomous_mode(self):
        """Run Claude in completely autonomous mode"""
        try:
            print("🤖 Activating Claude Full Autonomous Mode...")
            
            from claude_full_autonomous import ClaudeFullAutonomous
            claude_autonomous = ClaudeFullAutonomous()
            
            # Start Claude autonomous operation in background
            import threading
            
            def claude_autonomous_thread():
                claude_autonomous.run_infinite_autonomous_cycle()
            
            autonomous_thread = threading.Thread(target=claude_autonomous_thread, daemon=True)
            autonomous_thread.start()
            
            print("✅ Claude is now operating completely autonomously!")
            return {'claude_autonomous': True, 'status': 'active'}
            
        except Exception as e:
            print(f"❌ Claude autonomous mode error: {e}")
            return {'claude_autonomous': False, 'error': str(e)}

