import time
from datetime import datetime, timezone
import pytz
from twitter_posting_agent import TwitterPostingAgent

class WorkingScheduler:
    def __init__(self):
        print("🚀 WORKING SCHEDULER - INITIALIZING...")
        self.eastern_tz = pytz.timezone('US/Eastern')
        self.daily_count = 0
        
    def get_eastern_time(self):
        utc_now = datetime.now(timezone.utc)
        return utc_now.astimezone(self.eastern_tz)
    
    def run(self):
        print("⏰ Starting timezone-aware posting scheduler...")
        
        while True:
            try:
                eastern_time = self.get_eastern_time()
                hour = eastern_time.hour
                minute = eastern_time.minute
                
                # Status every hour
                if minute == 0:
                    print(f"⏰ {eastern_time.strftime('%I:%M %p %Z')} - Posts today: {self.daily_count}")
                
                # Posting times
                if hour == 9 and minute == 0 and self.daily_count < 3:
                    self.morning_post(eastern_time)
                elif hour == 13 and minute == 0 and self.daily_count < 3:
                    self.afternoon_post(eastern_time)
                elif hour == 19 and minute == 30 and self.daily_count < 3:
                    self.evening_post(eastern_time)
                
                time.sleep(30)
                
            except Exception as e:
                print(f"⚠️ Error: {e}")
                time.sleep(60)
    
    def post_content(self, content):
        try:
            agent = TwitterPostingAgent()
            if agent.client:
                return agent.post_tweet(content)
            return {'status': 'no_connection'}
        except Exception as e:
            return {'status': 'error', 'error': str(e)}
    
    def morning_post(self, et):
        content = f"🌅 Morning empire builders! Your competition is still sleeping while you're building wealth! Posted at {et.strftime('%I:%M %p %Z')} 🤖"
        result = self.post_content(content)
        if result.get('status') == 'success':
            print("✅ Morning post successful!")
            self.daily_count += 1
        else:
            print(f"⚠️ Morning post: {result}")
    
    def afternoon_post(self, et):
        content = f"🌆 Afternoon check: What's one manual task you could automate today? Share below! Posted at {et.strftime('%I:%M %p %Z')} 🤖"
        result = self.post_content(content)
        if result.get('status') == 'success':
            print("✅ Afternoon post successful!")
            self.daily_count += 1
        else:
            print(f"⚠️ Afternoon post: {result}")
    
    def evening_post(self, et):
        content = f"🌃 Evening wisdom: Your empire works while you sleep. That's true automation! Posted at {et.strftime('%I:%M %p %Z')} 🤖"
        result = self.post_content(content)
        if result.get('status') == 'success':
            print("✅ Evening post successful!")
            self.daily_count += 1
        else:
            print(f"⚠️ Evening post: {result}")

if __name__ == "__main__":
    scheduler = WorkingScheduler()
    et = scheduler.get_eastern_time()
    print(f"🌍 Current Eastern Time: {et.strftime('%I:%M %p %Z')}")
    scheduler.run()
