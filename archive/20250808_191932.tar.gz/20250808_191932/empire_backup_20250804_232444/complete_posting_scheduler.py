import time
import os
import json
from datetime import datetime, timedelta
from twitter_posting_agent import TwitterPostingAgent
from real_money_agent import RealMoneyAgent

class CompletePostingScheduler:
    def __init__(self):
        print("📅 COMPLETE POSTING SCHEDULER - INITIALIZING...")
        print("🎯 Setting up optimal posting schedule for maximum revenue!")
        
        self.posting_active = True
        self.daily_post_count = 0
        self.max_daily_posts = 3
        self.last_post_date = None
        
    def run_scheduler(self):
        """Run the complete posting scheduler"""
        print("🚀 STARTING COMPLETE POSTING SCHEDULER...")
        print("=" * 45)
        print("🌅 9:00 AM: Morning viral threads")
        print("🌆 1:00 PM: Afternoon engagement posts")
        print("🌃 7:30 PM: Evening prime content")
        print("📊 Monday 10:00 AM: Weekly strategy posts")
        print("=" * 45)
        
        while self.posting_active:
            try:
                current_time = datetime.now()
                current_hour = current_time.hour
                current_minute = current_time.minute
                
                # Reset daily counter at midnight
                if self.last_post_date != current_time.date():
                    self.daily_post_count = 0
                    self.last_post_date = current_time.date()
                    print(f"🗓️ New day: {current_time.date()} - Post counter reset")
                
                # Check for posting times
                if current_hour == 9 and current_minute == 0:
                    print("🌅 9:00 AM - MORNING POSTING TIME!")
                    self.morning_viral_post()
                    time.sleep(60)  # Wait 1 minute to avoid double posting
                    
                elif current_hour == 13 and current_minute == 0:
                    print("🌆 1:00 PM - AFTERNOON POSTING TIME!")
                    self.afternoon_engagement_post()
                    time.sleep(60)
                    
                elif current_hour == 19 and current_minute == 30:
                    print("🌃 7:30 PM - EVENING POSTING TIME!")
                    self.evening_prime_post()
                    time.sleep(60)
                    
                elif current_time.weekday() == 0 and current_hour == 10 and current_minute == 0:
                    print("📊 Monday 10:00 AM - WEEKLY STRATEGY TIME!")
                    self.weekly_strategy_post()
                    time.sleep(60)
                
                # Status update every hour
                if current_minute == 0:
                    self.hourly_status_update(current_time)
                
                time.sleep(30)  # Check every 30 seconds
                
            except KeyboardInterrupt:
                print("🛑 Posting Scheduler stopped by user")
                break
            except Exception as e:
                print(f"⚠️ Scheduler error: {e}")
                time.sleep(300)  # 5 minutes on error
    
    def hourly_status_update(self, current_time):
        """Provide hourly status updates"""
        print(f"\n⏰ HOURLY STATUS - {current_time.strftime('%H:%M')}")
        print(f"📊 Daily posts: {self.daily_post_count}/{self.max_daily_posts}")
        
        # Show next posting time
        next_posts = []
        current_hour = current_time.hour
        
        if current_hour < 9:
            next_posts.append("🌅 9:00 AM - Morning viral thread")
        if current_hour < 13:
            next_posts.append("🌆 1:00 PM - Afternoon engagement")
        if current_hour < 19 or (current_hour == 19 and current_time.minute < 30):
            next_posts.append("🌃 7:30 PM - Evening prime content")
            
        if next_posts:
            print("🎯 Upcoming today:")
            for post in next_posts:
                print(f"   {post}")
        else:
            print("✅ All daily posts completed!")
            
        print("-" * 35)
    
    def morning_viral_post(self):
        """Morning viral thread posting"""
        if self.daily_post_count >= self.max_daily_posts:
            print("📊 Daily post limit reached - skipping morning post")
            return
            
        print("🌅 EXECUTING MORNING VIRAL POST")
        print("=" * 35)
        
        try:
            # Generate fresh viral content
            print("📝 Generating fresh viral content...")
            money_agent = RealMoneyAgent()
            
            # Create custom morning viral thread
            morning_thread = '''🧵 Morning wisdom: The future belongs to those who build while others doubt. What are you building today? #MorningMotivation

1/8: Every successful empire started with a single decision to begin. Your empire starts with your next action.

2/8: Automation isn't about replacing humans - it's about amplifying human potential. What will you amplify today?

3/8: The best time to build systems was yesterday. The second best time is right now. Start building.

4/8: Your competition is still thinking about it. You're already doing it. That's the difference between success and mediocrity.

5/8: Small consistent actions compound into massive results. What's your one consistent action?

6/8: The tools exist. The knowledge is available. The only missing piece is your decision to start.

7/8: Your future self is counting on the decisions you make today. Make them count.

8/8: Ready to build your empire? Get our exclusive automation strategies → Newsletter in bio! 🚀'''
            
            # Post the thread
            twitter_agent = TwitterPostingAgent()
            result = twitter_agent.post_thread(morning_thread)
            
            if result.get('status') == 'success':
                print("✅ MORNING VIRAL THREAD POSTED SUCCESSFULLY!")
                print(f"📊 Posted at: {datetime.now().strftime('%H:%M:%S')}")
                self.daily_post_count += 1
                self.log_posting_success('morning_viral', result)
                
                # Track revenue potential
                print("💰 Revenue tracking: Morning post optimized for engagement")
            else:
                print(f"⚠️ Morning posting result: {result}")
                
        except Exception as e:
            print(f"❌ Morning posting error: {e}")
    
    def afternoon_engagement_post(self):
        """Afternoon engagement-focused post"""
        if self.daily_post_count >= self.max_daily_posts:
            print("📊 Daily post limit reached - skipping afternoon post")
            return
            
        print("🌆 EXECUTING AFTERNOON ENGAGEMENT POST")
        print("=" * 35)
        
        try:
            # Create engagement content
            engagement_posts = [
                "Quick question: What's the ONE automation that would save you 2+ hours daily? Let's brainstorm solutions! 🤖⏰",
                "Poll time: What's your biggest business challenge right now?\n🚀 Getting started\n📈 Scaling up\n🤖 Automation\n💰 Revenue optimization",
                "Afternoon check-in: What's one thing you automated this week that made your life easier? Share your wins! 🏆",
                "Real talk: What manual task are you still doing that could be automated in 2024? Let's solve it together! 💡"
            ]
            
            import random
            engagement_content = random.choice(engagement_posts)
            
            # Post engagement content
            twitter_agent = TwitterPostingAgent()
            result = twitter_agent.post_single_tweet(engagement_content)
            
            if result.get('status') == 'success':
                print("✅ AFTERNOON ENGAGEMENT POST SUCCESSFUL!")
                print(f"📊 Posted at: {datetime.now().strftime('%H:%M:%S')}")
                self.daily_post_count += 1
                print("🎯 Goal: Community building and interaction")
            else:
                print(f"⚠️ Afternoon posting result: {result}")
                
        except Exception as e:
            print(f"❌ Afternoon posting error: {e}")
    
    def evening_prime_post(self):
        """Evening prime time post"""
        if self.daily_post_count >= self.max_daily_posts:
            print("📊 Daily post limit reached - skipping evening post")
            return
            
        print("🌃 EXECUTING EVENING PRIME TIME POST")
        print("=" * 35)
        
        try:
            # Create prime time value content
            prime_posts = [
                "Evening wisdom: Your empire doesn't sleep. While you rest, your systems work. That's the power of true automation. 🌙⚡",
                "End-of-day thought: Success is built in private, celebrated in public. What are you building in private? 🏗️✨",
                "Prime time insight: The wealthy automate their income. The wise automate their impact. Which are you focusing on? 💰🌟",
                "Night reflection: Your competitors are binge-watching Netflix. You're building an empire. Guess who wins in 5 years? 🏆📺"
            ]
            
            import random
            prime_content = random.choice(prime_posts)
            
            # Post prime time content
            twitter_agent = TwitterPostingAgent()
            result = twitter_agent.post_single_tweet(prime_content)
            
            if result.get('status') == 'success':
                print("✅ EVENING PRIME TIME POST SUCCESSFUL!")
                print(f"📊 Posted at: {datetime.now().strftime('%H:%M:%S')}")
                self.daily_post_count += 1
                print("🎯 Goal: Value delivery and thought leadership")
            else:
                print(f"⚠️ Evening posting result: {result}")
                
        except Exception as e:
            print(f"❌ Evening posting error: {e}")
    
    def weekly_strategy_post(self):
        """Weekly strategy and insights post"""
        print("📊 EXECUTING WEEKLY STRATEGY POST")
        print("=" * 35)
        
        try:
            # Create weekly strategy thread
            strategy_thread = '''🧵 Weekly Empire Strategy: The Automation Advantage

1/6: This week's focus: Compound automation. Each system you build makes the next one easier and more powerful.

2/6: Key insight: 90% of businesses still run on manual processes. Your automation gives you a 10x advantage.

3/6: Strategic move: Document → Systematize → Automate → Optimize. Follow this sequence for any process.

4/6: Growth multiplier: One hour spent building systems saves ten hours of manual work. Invest in systems.

5/6: Empire mindset: You're not just saving time - you're buying freedom. What will you do with yours?

6/6: This week's challenge: Identify one 2-hour daily task. Automate it. Reclaim 10 hours weekly. Share your wins! 🚀'''
            
            # Post strategy thread
            twitter_agent = TwitterPostingAgent()
            result = twitter_agent.post_thread(strategy_thread)
            
            if result.get('status') == 'success':
                print("✅ WEEKLY STRATEGY THREAD POSTED!")
                print(f"📊 Posted at: {datetime.now().strftime('%H:%M:%S')}")
                print("🎯 Goal: Thought leadership and strategic insights")
            else:
                print(f"⚠️ Weekly posting result: {result}")
                
        except Exception as e:
            print(f"❌ Weekly posting error: {e}")
    
    def log_posting_success(self, post_type, result):
        """Log successful posting"""
        try:
            log_entry = {
                'timestamp': datetime.now().isoformat(),
                'post_type': post_type,
                'result': str(result),
                'daily_count': self.daily_post_count,
                'success': True
            }
            
            with open('posting_schedule_success.json', 'a') as f:
                f.write(json.dumps(log_entry) + '\n')
                
        except Exception as e:
            print(f"⚠️ Logging error: {e}")

if __name__ == "__main__":
    scheduler = CompletePostingScheduler()
    
    print("\n📅 COMPLETE POSTING SCHEDULER ACTIVE:")
    print("=" * 50)
    print("🌅 9:00 AM: Morning viral threads (peak engagement)")
    print("🌆 1:00 PM: Afternoon engagement posts")
    print("🌃 7:30 PM: Evening prime time content")
    print("📊 Monday 10:00 AM: Weekly strategy threads")
    print("🎯 Maximum 3 posts/day (quality over quantity)")
    print("=" * 50)
    
    scheduler.run_scheduler()
