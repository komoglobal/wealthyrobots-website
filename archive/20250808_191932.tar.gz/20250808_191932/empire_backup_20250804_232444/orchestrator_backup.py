import openai
import requests
import json
import os
import time
import schedule
from datetime import datetime, timedelta
from dotenv import load_dotenv
import threading
import sqlite3

load_dotenv()

class AgentOrchestrator:
    """Master orchestrator that manages all company agents"""
    
    def __init__(self):
        self.client = openai.OpenAI(
            api_key=os.getenv("OPENAI_API_KEY") or "your-openai-api-key-here"
        )
        
        # Initialize database for tracking
        self.init_database()
        
        # Agent states
        self.agents = {
            'ceo': {'status': 'idle', 'last_run': None},
            'content': {'status': 'idle', 'last_run': None},
            'ads': {'status': 'idle', 'last_run': None},
            'analytics': {'status': 'idle', 'last_run': None},
            'social': {'status': 'idle', 'last_run': None}
        }
        
        # Company metrics
        self.metrics = {
            'total_content_pieces': 0,
            'total_revenue': 0,
            'active_campaigns': 0,
            'conversion_rate': 0
        }
    
    def init_database(self):
        """Initialize SQLite database for tracking company performance"""
        self.conn = sqlite3.connect('company_data.db', check_same_thread=False)
        cursor = self.conn.cursor()
        
        # Create tables
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS content_performance (
                id INTEGER PRIMARY KEY,
                title TEXT,
                content_type TEXT,
                topic TEXT,
                views INTEGER DEFAULT 0,
                clicks INTEGER DEFAULT 0,
                revenue REAL DEFAULT 0,
                created_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS agent_logs (
                id INTEGER PRIMARY KEY,
                agent_name TEXT,
                action TEXT,
                result TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS revenue_streams (
                id INTEGER PRIMARY KEY,
                stream_type TEXT,
                amount REAL,
                source TEXT,
                date_earned TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        self.conn.commit()
    
    def log_agent_action(self, agent_name, action, result):
        """Log agent actions to database"""
        cursor = self.conn.cursor()
        cursor.execute('''
            INSERT INTO agent_logs (agent_name, action, result)
            VALUES (?, ?, ?)
        ''', (agent_name, action, str(result)[:1000]))
        self.conn.commit()
    
    def get_company_status(self):
        """Get comprehensive company status"""
        print("=" * 60)
        print("🏢 AUTONOMOUS COMPANY STATUS REPORT")
        print("=" * 60)
        
        # Agent statuses
        print("\n🤖 AGENT STATUS:")
        for agent, status in self.agents.items():
            status_emoji = "🟢" if status['status'] == 'active' else "🔴"
            last_run = status['last_run'] or "Never"
            print(f"  {status_emoji} {agent.upper()}: {status['status']} (Last: {last_run})")
        
        # Performance metrics
        cursor = self.conn.cursor()
        
        # Content stats
        cursor.execute('SELECT COUNT(*) FROM content_performance')
        total_content = cursor.fetchone()[0]
        
        cursor.execute('SELECT SUM(revenue) FROM content_performance WHERE revenue > 0')
        content_revenue = cursor.fetchone()[0] or 0
        
        cursor.execute('SELECT SUM(amount) FROM revenue_streams')
        total_revenue = cursor.fetchone()[0] or 0
        
        print(f"\n📊 PERFORMANCE METRICS:")
        print(f"  📝 Total Content Pieces: {total_content}")
        print(f"  💰 Total Revenue: ${total_revenue:.2f}")
        print(f"  📈 Content Revenue: ${content_revenue:.2f}")
        print(f"  🎯 Active Campaigns: {self.metrics['active_campaigns']}")
        
        # Recent activity
        cursor.execute('''
            SELECT agent_name, action, timestamp 
            FROM agent_logs 
            ORDER BY timestamp DESC 
            LIMIT 5
        ''')
        recent_logs = cursor.fetchall()
        
        print(f"\n📋 RECENT ACTIVITY:")
        for log in recent_logs:
            print(f"  • {log[0]}: {log[1]} ({log[2]})")
        
        print("=" * 60)
    
    def run_ceo_analysis(self):
        """Run CEO strategic analysis"""
        print("🤖 Running CEO Analysis...")
        self.agents['ceo']['status'] = 'active'
        
        try:
            # Import and run CEO agent
            from ultimate_ceo_agent import UltimateAutonomousCEO
            ceo = UltimateAutonomousCEO()
            result = ceo.run_ultimate_ceo_cycle()
            
            self.log_agent_action('CEO', 'Strategic Analysis', 'Completed market analysis and decision making')
            self.agents['ceo']['last_run'] = datetime.now().strftime('%Y-%m-%d %H:%M')
            
        except Exception as e:
            self.log_agent_action('CEO', 'Strategic Analysis', f'Error: {str(e)}')
        
        self.agents['ceo']['status'] = 'idle'
    
    def run_content_creation(self):
        """Run content creation cycle"""
        print("✍️ Running Content Creation...")
        self.agents['content']['status'] = 'active'
        
        try:
            # Import and run content agent
            from content_agent import ContentAgent
            content_agent = ContentAgent()
            result = content_agent.run_content_cycle()
            
            # Log to database
            cursor = self.conn.cursor()
            cursor.execute('''
                INSERT INTO content_performance (title, content_type, topic)
                VALUES (?, ?, ?)
            ''', (result.get('title', 'Generated Content'), 'blog', result.get('topic', 'AI')))
            self.conn.commit()
            
            self.log_agent_action('Content', 'Content Creation', 'Generated new content piece')
            self.agents['content']['last_run'] = datetime.now().strftime('%Y-%m-%d %H:%M')
            
        except Exception as e:
            self.log_agent_action('Content', 'Content Creation', f'Error: {str(e)}')
        
        self.agents['content']['status'] = 'idle'
    
    def run_ad_placement(self):
        """Run ad placement optimization"""
        print("🎯 Running Ad Placement...")
        self.agents['ads']['status'] = 'active'
        
        try:
            # Import and run ad placement agent
            from ad_placement_agent import AdPlacementAgent
            ad_agent = AdPlacementAgent()
            result = ad_agent.run_ad_cycle()
            
            # Simulate revenue generation
            estimated_revenue = 50 + (time.time() % 100)  # Random revenue simulation
            cursor = self.conn.cursor()
            cursor.execute('''
                INSERT INTO revenue_streams (stream_type, amount, source)
                VALUES (?, ?, ?)
            ''', ('affiliate', estimated_revenue, 'Ad Placements'))
            self.conn.commit()
            
            self.log_agent_action('Ads', 'Ad Placement', f'Generated ${estimated_revenue:.2f} in revenue')
            self.agents['ads']['last_run'] = datetime.now().strftime('%Y-%m-%d %H:%M')
            
        except Exception as e:
            self.log_agent_action('Ads', 'Ad Placement', f'Error: {str(e)}')
        
        self.agents['ads']['status'] = 'idle'
    
    def run_analytics_agent(self):
        """Run analytics and optimization"""
        print("📊 Running Analytics...")
        self.agents['analytics']['status'] = 'active'
        
        try:
            prompt = """
            Analyze the current performance of our automated company:
            
            1. Review content performance metrics
            2. Identify optimization opportunities
            3. Suggest strategic improvements
            4. Recommend scaling strategies
            
            Provide actionable insights for maximizing automation and revenue.
            """
            
            response = self.client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.3
            )
            
            analysis = response.choices[0].message.content
            
            # Save analysis
            with open('analytics_report.json', 'w') as f:
                json.dump({
                    'timestamp': datetime.now().isoformat(),
                    'analysis': analysis,
                    'metrics': self.metrics
                }, f, indent=2)
            
            self.log_agent_action('Analytics', 'Performance Analysis', 'Generated analytics report')
            self.agents['analytics']['last_run'] = datetime.now().strftime('%Y-%m-%d %H:%M')
            
            print("📊 Analytics Report:")
            print(analysis[:200] + "...")
            
        except Exception as e:
            self.log_agent_action('Analytics', 'Performance Analysis', f'Error: {str(e)}')
        
        self.agents['analytics']['status'] = 'idle'
    
    def run_social_media_agent(self):
        """Run social media automation"""
        print("📱 Running Social Media Agent...")
        self.agents['social']['status'] = 'active'
        
        try:
            prompt = """
            Create engaging social media posts for our AI/tech content:
            
            1. Create 3 Twitter posts about AI trends
            2. Create 1 LinkedIn post about automation
            3. Create 1 Instagram caption about tech innovation
            
            Make them engaging, use relevant hashtags, and include subtle calls-to-action.
            """
            
            response = self.client.chat.completions.create(
                model="gpt-3.5-turbo",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7
            )
            
            social_content = response.choices[0].message.content
            
            # Save social content
            with open('social_media_posts.json', 'w') as f:
                json.dump({
                    'timestamp': datetime.now().isoformat(),
                    'posts': social_content
                }, f, indent=2)
            
            self.log_agent_action('Social', 'Social Media Posts', 'Generated social media content')
            self.agents['social']['last_run'] = datetime.now().strftime('%Y-%m-%d %H:%M')
            
            print("📱 Social Media Posts Created!")
            
        except Exception as e:
            self.log_agent_action('Social', 'Social Media Posts', f'Error: {str(e)}')
        
        self.agents['social']['status'] = 'idle'
    
    def run_full_automation_cycle(self):
        """Run complete automation cycle"""
        print("\n🚀 STARTING FULL AUTOMATION CYCLE")
        print("=" * 60)
        
        # Sequential execution for dependencies
        self.run_ceo_analysis()
        time.sleep(2)
        
        self.run_content_creation()
        time.sleep(2)
        
        self.run_ad_placement()
        time.sleep(2)
        
        # Parallel execution for independent tasks
        analytics_thread = threading.Thread(target=self.run_analytics_agent)
        social_thread = threading.Thread(target=self.run_social_media_agent)
        
        analytics_thread.start()
        social_thread.start()
        
        analytics_thread.join()
        social_thread.join()
        
        print("\n✅ FULL AUTOMATION CYCLE COMPLETE!")
        self.get_company_status()
    
    def schedule_automation(self):
        """Schedule automated runs"""
        # Schedule different agents at different intervals
        schedule.every(1).hours.do(self.run_content_creation)
        schedule.every(2).hours.do(self.run_ad_placement)
        schedule.every(6).hours.do(self.run_ceo_analysis)
        schedule.every(4).hours.do(self.run_analytics_agent)
        schedule.every(3).hours.do(self.run_social_media_agent)
        
        print("📅 Automation scheduled!")
        print("  • Content Creation: Every 1 hour")
        print("  • Ad Placement: Every 2 hours")
        print("  • CEO Analysis: Every 6 hours")
        print("  • Analytics: Every 4 hours")
        print("  • Social Media: Every 3 hours")
        
        while True:
            schedule.run_pending()
            time.sleep(60)  # Check every minute
    
    def start_company(self):
        """Start the autonomous company"""
        print("🏢 STARTING AUTONOMOUS COMPANY...")
        print("=" * 60)
        
        # Initial status
        self.get_company_status()
        
        # Run initial cycle
        self.run_full_automation_cycle()
        
        # Ask user for automation mode
        mode = input("\nChoose mode:\n1. Run scheduled automation\n2. Manual control\n3. Exit\nChoice: ")
        
        if mode == "1":
            print("\n🤖 Starting scheduled automation...")
            self.schedule_automation()
        elif mode == "2":
            self.manual_control()
        else:
            print("👋 Company operations paused.")
    
    def manual_control(self):
        """Manual control interface"""
        while True:
            print("\n" + "=" * 40)
            print("🎮 MANUAL CONTROL PANEL")
            print("=" * 40)
            print("1. Run CEO Analysis")
            print("2. Create Content")
            print("3. Optimize Ads")
            print("4. Generate Analytics")
            print("5. Post Social Media")
            print("6. Full Automation Cycle")
            print("7. Company Status")
            print("8. Exit")
            
            choice = input("\nSelect action: ")
            
            if choice == "1":
                self.run_ceo_analysis()
            elif choice == "2":
                self.run_content_creation()
            elif choice == "3":
                self.run_ad_placement()
            elif choice == "4":
                self.run_analytics_agent()
            elif choice == "5":
                self.run_social_media_agent()
            elif choice == "6":
                self.run_full_automation_cycle()
            elif choice == "7":
                self.get_company_status()
            elif choice == "8":
                print("👋 Exiting manual control.")
                break
            else:
                print("❌ Invalid choice. Try again.")

if __name__ == "__main__":
    orchestrator = AgentOrchestrator()
    orchestrator.start_company()
