#!/usr/bin/env python3
"""
Quick fix for live_orchestrator.py syntax error
"""

import os
import shutil

def fix_orchestrator_syntax():
    """Fix the syntax error in live_orchestrator.py"""
    
    # Backup the current file
    shutil.copy2('live_orchestrator.py', 'live_orchestrator_broken.py')
    print("✅ Backed up broken orchestrator")
    
    try:
        with open('live_orchestrator.py', 'r') as f:
            content = f.read()
        
        lines = content.split('\n')
        fixed_lines = []
        
        for i, line in enumerate(lines):
            # Check for the problematic lines
            if 'self.smart_affiliate = SmartAffiliateAgent()' in line:
                # Check if we're inside a class method properly
                if line.strip().startswith('self.smart_affiliate'):
                    # This is likely the issue - it might be outside a method
                    # Let's comment it out and add it properly
                    fixed_lines.append(f"        # {line.strip()} # Fixed: moved to proper location")
                else:
                    fixed_lines.append(line)
            elif 'self.content_selector = DynamicContentSelector()' in line:
                fixed_lines.append(f"        # {line.strip()} # Fixed: moved to proper location")
            elif 'self.visual_affiliate = VisualAffiliateAgent()' in line:
                fixed_lines.append(f"        # {line.strip()} # Fixed: moved to proper location")
            else:
                fixed_lines.append(line)
        
        # Now find the __init__ method and add the imports properly
        for i, line in enumerate(fixed_lines):
            if 'def __init__' in line:
                # Find the end of the __init__ method
                j = i + 1
                while j < len(fixed_lines) and (fixed_lines[j].startswith('        ') or fixed_lines[j].strip() == ''):
                    j += 1
                
                # Insert the affiliate agent initialization before the end
                affiliate_init = [
                    "        # Initialize affiliate agents (consolidated approach)",
                    "        try:",
                    "            from smart_affiliate_agent import SmartAffiliateAgent",
                    "            self.smart_affiliate = SmartAffiliateAgent()",
                    "        except ImportError:",
                    "            print('SmartAffiliateAgent not found - using fallback')",
                    "            self.smart_affiliate = None",
                    "",
                    "        try:",
                    "            from dynamic_content_selector import DynamicContentSelector", 
                    "            self.content_selector = DynamicContentSelector()",
                    "        except ImportError:",
                    "            print('DynamicContentSelector not found - using fallback')",
                    "            self.content_selector = None",
                    "",
                    "        try:",
                    "            from visual_affiliate_agent import VisualAffiliateAgent",
                    "            self.visual_affiliate = VisualAffiliateAgent()",
                    "        except ImportError:",
                    "            print('VisualAffiliateAgent not found - using fallback')",
                    "            self.visual_affiliate = None"
                ]
                
                # Insert the proper initialization
                for init_line in reversed(affiliate_init):
                    fixed_lines.insert(j - 1, init_line)
                
                break
        
        # Write the fixed version
        with open('live_orchestrator.py', 'w') as f:
            f.write('\n'.join(fixed_lines))
        
        print("✅ Fixed syntax error in live_orchestrator.py")
        return True
        
    except Exception as e:
        print(f"❌ Error fixing orchestrator: {e}")
        return False

def validate_syntax():
    """Validate the Python syntax"""
    try:
        import ast
        with open('live_orchestrator.py', 'r') as f:
            content = f.read()
        
        ast.parse(content)
        print("✅ Python syntax is now valid")
        return True
        
    except SyntaxError as e:
        print(f"❌ Syntax error still exists: {e}")
        print(f"   Line {e.lineno}: {e.text}")
        return False
    except Exception as e:
        print(f"❌ Error validating syntax: {e}")
        return False

def main():
    print("🔧 Fixing Live Orchestrator Syntax Error")
    print("="*50)
    
    # Fix the syntax
    if fix_orchestrator_syntax():
        # Validate the fix
        if validate_syntax():
            print("\n🟢 Orchestrator syntax fixed successfully!")
            print("You can now restart it safely.")
        else:
            print("\n🔴 Syntax still has issues - manual review needed")
    else:
        print("\n🔴 Could not fix orchestrator automatically")
    
    print("\nNext steps:")
    print("1. pkill -f live_orchestrator.py")
    print("2. python3 live_orchestrator.py")

if __name__ == "__main__":
    main()
