import time
from datetime import datetime, timezone
import pytz
from twitter_posting_agent import TwitterPostingAgent

class CleanEmpireScheduler:
    def __init__(self):
        print("🧹 CLEAN EMPIRE SCHEDULER - SINGLE POSTER")
        print("🎯 No conflicts, no rate limits, just clean posting!")
        
        self.eastern_tz = pytz.timezone('US/Eastern')
        self.daily_count = 0
        self.last_posts = {'morning': None, 'afternoon': None, 'evening': None}
        
    def get_eastern_time(self):
        return datetime.now(timezone.utc).astimezone(self.eastern_tz)
    
    def already_posted_today(self, post_type):
        """Check if we already posted this type today"""
        et = self.get_eastern_time()
        today = et.date()
        
        last_post = self.last_posts.get(post_type)
        if last_post and last_post.date() == today:
            return True
        return False
    
    def run(self):
        print("⏰ Starting CLEAN posting scheduler...")
        print(f"🌍 Timezone: Eastern Time")
        print("🎯 Posts: 9AM, 1PM, 7:30PM")
        print("=" * 40)
        
        while True:
            try:
                et = self.get_eastern_time()
                hour = et.hour
                minute = et.minute
                
                # Status every hour
                if minute == 0:
                    print(f"\n⏰ {et.strftime('%I:%M %p %Z')} - Daily posts: {self.daily_count}/3")
                
                # Morning post - 9:00 AM
                if hour == 9 and minute == 0 and not self.already_posted_today('morning'):
                    print("🌅 9:00 AM - MORNING POST!")
                    if self.morning_post(et):
                        self.last_posts['morning'] = et
                        self.daily_count += 1
                    time.sleep(70)  # Avoid double posting
                
                # Afternoon post - 1:00 PM  
                elif hour == 13 and minute == 0 and not self.already_posted_today('afternoon'):
                    print("🌆 1:00 PM - AFTERNOON POST!")
                    if self.afternoon_post(et):
                        self.last_posts['afternoon'] = et
                        self.daily_count += 1
                    time.sleep(70)
                
                # Evening post - 7:30 PM
                elif hour == 19 and minute == 30 and not self.already_posted_today('evening'):
                    print("🌃 7:30 PM - EVENING POST!")
                    if self.evening_post(et):
                        self.last_posts['evening'] = et
                        self.daily_count += 1
                    time.sleep(70)
                
                # Reset counter at midnight
                elif hour == 0 and minute == 0:
                    self.daily_count = 0
                    print("🗓️ New day - counter reset")
                
                time.sleep(30)
                
            except Exception as e:
                print(f"⚠️ Error: {e}")
                time.sleep(60)
    
    def post_safely(self, content):
        """Post with safety checks"""
        try:
            agent = TwitterPostingAgent()
            if not agent.client:
                print("❌ No Twitter connection")
                return False
            
            result = agent.post_tweet(content)
            
            if result and result.get('status') == 'success':
                print("✅ Post successful!")
                return True
            else:
                print(f"⚠️ Post failed: {result}")
                return False
                
        except Exception as e:
            print(f"❌ Posting error: {e}")
            return False
    
    def morning_post(self, et):
        content = f"""🌅 Good morning, empire builders!

While your competition hits snooze, you're already building wealth!

💪 Success starts early
🚀 Your empire never sleeps  
⚡ Automation works 24/7

Posted at {et.strftime('%I:%M %p %Z')} by your clean empire 🤖

#MorningEmpire #WealthBuilding"""
        
        return self.post_safely(content)
    
    def afternoon_post(self, et):
        content = f"""🌆 Afternoon empire check-in!

Quick question: What's ONE manual task you could automate today?

Share your biggest automation opportunity below! 👇

Posted at {et.strftime('%I:%M %p %Z')} 🤖

#AutomationOpportunity #EmpireBuilding"""
        
        return self.post_safely(content)
    
    def evening_post(self, et):
        content = f"""🌃 Evening empire wisdom:

Your empire doesn't sleep. While you rest tonight, your systems generate wealth.

That's the true power of automation! 💰

What system will you build tomorrow? 🏗️

Posted at {et.strftime('%I:%M %p %Z')} 🤖

#EveningWisdom #PassiveIncome"""
        
        return self.post_safely(content)

if __name__ == "__main__":
    scheduler = CleanEmpireScheduler()
    et = scheduler.get_eastern_time()
    print(f"\n🌍 Current Eastern Time: {et.strftime('%I:%M %p %Z')}")
    
    # Show next posting opportunity
    hour = et.hour
    if hour < 9:
        print(f"🎯 Next post: 9:00 AM EST")
    elif hour < 13:
        print(f"🎯 Next post: 1:00 PM EST") 
    elif hour < 19:
        print(f"🎯 Next post: 7:30 PM EST")
    else:
        print(f"🎯 Next post: 9:00 AM EST tomorrow")
    
    scheduler.run()
