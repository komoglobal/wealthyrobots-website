#!/usr/bin/env python3
"""
Fix the orchestrator to use the correct content selector method
"""

# Read the current orchestrator and fix the method call
with open('live_orchestrator.py', 'r') as f:
    content = f.read()

# Replace the incorrect method call with the correct one
fixed_content = content.replace(
    'selection = self.content_selector.select_content_type()',
    'content_file = self.content_selector.get_optimized_content()'
)

# Also need to update the logic that uses the selection
fixed_content = fixed_content.replace(
    """content_type = selection.get('content_type', 'educational')
            is_affiliate = selection.get('was_affiliate', False)
            reasoning = selection.get('reasoning', 'Content selector decision')""",
    """# Parse the content file to determine type
            if 'affiliate' in content_file.lower():
                content_type = 'affiliate'
                is_affiliate = True
            elif 'educational' in content_file.lower():
                content_type = 'educational'
                is_affiliate = False
            elif 'community' in content_file.lower():
                content_type = 'community'
                is_affiliate = False
            elif 'entertaining' in content_file.lower():
                content_type = 'entertaining'
                is_affiliate = False
            else:
                content_type = 'educational'
                is_affiliate = False
            
            reasoning = f"Content selector chose: {content_file}\""""
)

# Write the fixed orchestrator
with open('live_orchestrator.py', 'w') as f:
    f.write(fixed_content)

print("✅ Orchestrator method fixed!")
print("✅ Now uses get_optimized_content() method")
print("✅ Content selector integration corrected")
