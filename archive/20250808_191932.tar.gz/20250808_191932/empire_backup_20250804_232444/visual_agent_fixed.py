#!/usr/bin/env python3
"""
EMPIRE_AGENT_INFO:
NAME: Visual Content Generator (Fixed)
PURPOSE: Generate graphics and visuals for articles
CATEGORY: Visual & Creative
STATUS: Phase 2 - Ready for autonomous operation
"""

import openai
import os
from datetime import datetime

class VisualContentAgent:
    def __init__(self):
        self.client = openai.OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        
    def generate_article_visuals(self, article_content, topic):
        """Generate visual concepts for articles"""
        
        prompt = f"""Create 3 visual concepts for an article about: {topic}

        Article content preview: {article_content[:500]}...

        For each visual, create:
        1. CSS-based graphic design code
        2. Professional visual concept
        3. Placement recommendation

        Focus on:
        - Modern, professional design
        - AI/tech themes matching Wealthy Robots brand
        - Gradients and animations
        - Charts, icons, or infographics
        - Mobile responsive

        Return CSS code that creates engaging visual elements."""
        
        try:
            response = self.client.chat.completions.create(
                model="gpt-4",
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            print(f"❌ Visual generation error: {e}")
            return ""
    
    def add_visuals_to_article(self, article_html, visuals_css):
        """Inject visuals into article HTML"""
        
        # Insert visual CSS into the article
        if "<style>" in article_html and visuals_css:
            article_html = article_html.replace(
                "</style>", 
                f"\n        {visuals_css}\n    </style>"
            )
        
        return article_html

if __name__ == "__main__":
    agent = VisualContentAgent()
    print("✅ Visual Content Agent - Fixed and Ready")
