import subprocess
import time
from datetime import datetime

def run_automated_twitter_empire():
    """Run your empire: Generate content + Post to Twitter automatically"""
    print("🤖 AUTONOMOUS TWITTER EMPIRE - STARTING...")
    print(f"🕐 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    cycle = 0
    
    while True:
        try:
            cycle += 1
            print(f"\n🔄 EMPIRE CYCLE #{cycle}")
            print("=" * 40)
            
            # 1. Generate fresh money-making content
            print("💰 Generating viral content...")
            money_result = subprocess.run(['python3', 'real_money_agent.py'])
            
            if money_result.returncode == 0:
                print("✅ Content generated!")
                
                # 2. Post to Twitter
                print("🐦 Posting to Twitter...")
                twitter_result = subprocess.run(['python3', 'post_to_twitter.py'])
                
                if twitter_result.returncode == 0:
                    print("✅ Posted to Twitter!")
                    print("🎯 Check @WealthyRobot for latest posts!")
                else:
                    print("⚠️ Twitter posting had issues")
            else:
                print("⚠️ Content generation had issues")
            
            print(f"\n⏰ Cycle #{cycle} complete. Next cycle in 4 hours...")
            print("💡 Your empire is working autonomously!")
            
            # Wait 4 hours between posts (14400 seconds)
            time.sleep(14400)
            
        except KeyboardInterrupt:
            print(f"\n👋 Stopping empire after {cycle} cycles...")
            break
        except Exception as e:
            print(f"⚠️ Empire error: {e}")
            print("🔄 Continuing in 1 hour...")
            time.sleep(3600)

if __name__ == "__main__":
    run_automated_twitter_empire()
