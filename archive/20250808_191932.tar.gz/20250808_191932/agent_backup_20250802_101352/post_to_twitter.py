from twitter_posting_agent import TwitterPostingAgent
import glob

print("🐦 POSTING TO TWITTER...")
print("=" * 30)

# Initialize Twitter agent
twitter = TwitterPostingAgent()

if twitter.client:
    print("✅ Connected to Twitter as @WealthyRobot")
    
    # Find latest content
    files = glob.glob("smart_viral_thread_*.txt")
    
    if files:
        latest = sorted(files)[-1]
        print(f"📄 Using: {latest}")
        
        with open(latest, 'r') as f:
            content = f.read()
        
        print("🔍 Analyzing content structure...")
        print(f"📊 Content length: {len(content)} characters")
        
        # Look for different thread markers
        thread_markers = [
            "YOUR VIRAL THREAD",
            "VIRAL THREAD", 
            "Thread:",
            "========================================",
            "1/"
        ]
        
        thread_content = None
        
        for marker in thread_markers:
            if marker in content:
                print(f"✅ Found marker: {marker}")
                start = content.find(marker)
                
                if marker == "1/":
                    # Extract from first tweet to end of thread
                    thread_content = content[start:]
                    # Limit to reasonable length
                    if len(thread_content) > 2000:
                        thread_content = thread_content[:2000]
                else:
                    # Extract section after marker
                    end = content.find("============================================================", start + len(marker))
                    if end == -1:
                        end = start + 1500
                    thread_content = content[start:end]
                break
        
        if thread_content:
            print("✅ Thread content extracted!")
            print(f"📝 Preview: {thread_content[:100]}...")
            
            # Post it
            result = twitter.post_thread(thread_content)
            
            if result["status"] == "success":
                print(f"🎉 SUCCESS! Posted {result['tweets_posted']} tweets!")
                print("🔗 Check https://twitter.com/WealthyRobot")
            else:
                print(f"❌ Failed: {result}")
        else:
            print("❌ No thread content found with any marker")
            print("📄 Content preview:")
            print(content[:500] + "..." if len(content) > 500 else content)
    else:
        print("❌ No content files found")
        print("💡 Run: python3 real_money_agent.py first")
else:
    print("❌ Twitter connection failed")
