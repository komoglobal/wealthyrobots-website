#!/usr/bin/env python3
"""
EMPIRE_AGENT_INFO:
NAME: Live Orchestrator - Final CEO Integration
PURPOSE: Master agent workflow management with CEO approval for deployments
CATEGORY: Coordination Layer (Master Controllers)
STATUS: Final - Full Autonomous Operation
"""

import time
import subprocess
import json
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

class LiveOrchestratorFinal:
    def __init__(self):
        self.cycle_count = 0
        self.config = {'posting_enabled': True, 'emergency_mode': False}
    
    def should_create_content(self):
        return True
    
    def create_content(self):
        try:
            result = subprocess.run(['python3', 'content_agent_complete.py'], 
                                  capture_output=True, text=True)
            
            if "HTML Article Created:" in result.stdout:
                filename = result.stdout.split("HTML Article Created: ")[1].split("\n")[0]
                return filename
        except Exception as e:
            print(f"❌ Content creation error: {e}")
        return None
    
    def run_cycle(self):
        self.cycle_count += 1
        print(f"\n🔄 Orchestrator Cycle #{self.cycle_count}")
        print(f"⏰ Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        if self.should_create_content():
            print("📝 Time to create new content...")
            content_file = self.create_content()
            
            if content_file:
                print(f"✅ Content created: {content_file}")
                print("👑 Consulting CEO for deployment decision...")
                
                try:
                    from ultimate_ceo_agent import UltimateAutonomousCEO
                    ceo = UltimateAutonomousCEO()
                    
                    decision = ceo.make_strategic_decision(f"Deploy content: {content_file}")
                    print(f"👑 CEO Decision: {decision['decision']}")
                    
                    if 'Proceed' in decision['decision']:
                        print("🚀 CEO APPROVED - Initiating auto-deployment...")
                        
                        from github_auto_deploy_agent import GitHubAutoDeployAgent
                        deploy_agent = GitHubAutoDeployAgent()
                        
                        with open(content_file, 'r') as f:
                            content = f.read()
                        
                        deploy_result = deploy_agent.auto_deploy_article(content_file, content)
                        
                        if deploy_result:
                            print("✅ Content deployed to wealthyrobots.com")
                            print("📱 Triggering social media posting...")
                            subprocess.run(['python3', 'social_media_agent.py'])
                            print("🎉 AUTONOMOUS CYCLE COMPLETE!")
                            print(f"🌐 Live at: https://wealthyrobots.com/{content_file}")
                    else:
                        print("⏸️ CEO deferred deployment")
                
                except Exception as e:
                    print(f"❌ CEO consultation error: {e}")
        
        print("✅ Cycle complete")
    
    def run_continuous(self):
        print("🚀 FINAL AUTONOMOUS WEALTHYROBOT EMPIRE")
        print("🏰 CEO-Approved Autonomous Deployment Active")
        print("=" * 60)
        
        while True:
            try:
                self.run_cycle()
                wait_time = 1800  # 30 minutes
                print(f"⏰ Next cycle in {wait_time//60} minutes...")
                time.sleep(wait_time)
            except KeyboardInterrupt:
                print("\n🛑 Empire stopped by user")
                break
            except Exception as e:
                print(f"❌ Error: {e}")
                time.sleep(300)

if __name__ == "__main__":
    orchestrator = LiveOrchestratorFinal()
    orchestrator.run_continuous()
