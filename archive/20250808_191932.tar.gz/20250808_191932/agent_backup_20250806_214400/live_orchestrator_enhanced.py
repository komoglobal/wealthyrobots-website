
# DEPRECATED: This agent has been merged into live_orchestrator_final.py
# Please use live_orchestrator_final.py instead
# This file will be removed in future updates

# DEPRECATED: This agent has been merged into live_orchestrator_final.py
# Please use live_orchestrator_final.py instead
# This file will be removed in future updates

# DEPRECATED: This agent has been merged into live_orchestrator_final.py
# Please use live_orchestrator_final.py instead
# This file will be removed in future updates

# DEPRECATED: This agent has been merged into live_orchestrator_final.py
# Please use live_orchestrator_final.py instead
# This file will be removed in future updates

# DEPRECATED: This agent has been merged into live_orchestrator_final.py
# Please use live_orchestrator_final.py instead
# This file will be removed in future updates

# DEPRECATED: This agent has been merged into live_orchestrator_final.py
# Please use live_orchestrator_final.py instead
# This file will be removed in future updates
#!/usr/bin/env python3
"""
EMPIRE_AGENT_INFO:
NAME: Live Orchestrator with CEO Integration
PURPOSE: Master agent workflow management with CEO approval for deployments
CATEGORY: Coordination Layer (Master Controllers)
STATUS: Enhanced - CEO Integrated
"""

import time
import subprocess
import json
from datetime import datetime
from dotenv import load_dotenv

load_dotenv()

class LiveOrchestratorEnhanced:
    def __init__(self):
        self.cycle_count = 0
        self.config = self.load_config()
        
        # Import content selector
        try:
            from dynamic_content_selector import DynamicContentSelector
            self.content_selector = DynamicContentSelector()
            print("✅ Content selector imported successfully")
        except ImportError:
            print("⚠️ Content selector not available")
            self.content_selector = None
    
    def load_config(self):
        try:
            with open('live_config.json', 'r') as f:
                return json.load(f)
        except:
            return {'posting_enabled': True, 'emergency_mode': False}
    
    def should_create_content(self):
        """Check if it's time to create new content"""
        # Simple logic: create content every cycle for now
        return True
    
    def create_content(self):
        """Create content using content agent"""
        try:
            result = subprocess.run(['python3', 'content_agent_complete.py'], 
                                  capture_output=True, text=True)
            
            if "HTML Article Created:" in result.stdout:
                filename = result.stdout.split("HTML Article Created: ")[1].split("\n")[0]
                return filename
            
        except Exception as e:
            print(f"❌ Content creation error: {e}")
        
        return None
    
    def run_cycle(self):
        """Run one orchestrator cycle with CEO integration"""
        self.cycle_count += 1
        print(f"\n🔄 Orchestrator Cycle #{self.cycle_count}")
        print(f"⏰ Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        
        # Check configuration
        if self.config.get('emergency_mode', False):
            print("🚨 Emergency mode active - limiting operations")
            return
        
        if not self.config.get('posting_enabled', True):
            print("⚠️ Posting disabled in config")
            return
        
        # Content creation decision
        if self.should_create_content():
            print("📝 Time to create new content...")
            content_file = self.create_content()
            
            if content_file:
                print(f"✅ Content created: {content_file}")
                
                # NEW: Ask CEO for deployment approval
                print("👑 Consulting CEO for deployment decision...")
                try:
                    from ultimate_ceo_agent import UltimateAutonomousCEO
                    ceo = UltimateAutonomousCEO()
                    
                    # CEO makes strategic decision
                    decision = ceo.make_strategic_decision(f"Deploy content: {content_file}")
                    print(f"👑 CEO Decision: {decision['decision']}")
                    
                    if decision['decision'] == 'Proceed with growth strategy':
                        print("🚀 CEO APPROVED - Initiating auto-deployment...")
                        
                        # AUTO-DEPLOY via GitHub Agent
                        from github_auto_deploy_agent import GitHubAutoDeployAgent
                        deploy_agent = GitHubAutoDeployAgent()
                        
                        with open(content_file, 'r') as f:
                            content = f.read()
                        
                        deploy_result = deploy_agent.auto_deploy_article(content_file, content)
                        
                        if deploy_result:
                            print("✅ Content deployed to wealthyrobots.com")
                            
                            # Post to social media
                            print("📱 Triggering social media posting...")
                            subprocess.run(['python3', 'social_media_agent.py'])
                            
                            print("🎉 AUTONOMOUS CYCLE COMPLETE!")
                            print(f"🌐 Live at: https://wealthyrobots.com/{content_file}")
                        else:
                            print("⚠️ Deployment failed - check GitHub agent")
                    
                    else:
                        print("⏸️ CEO deferred deployment for strategic reasons")
                        print(f"💭 Reasoning: {decision.get('reasoning', 'Not specified')}")
                
                except Exception as e:
                    print(f"❌ CEO consultation error: {e}")
                    print("⚠️ Falling back to manual deployment mode")
                
        else:
            print("⏰ Not time for new content yet")
        
        # Log cycle completion
        cycle_log = {
            'timestamp': datetime.now().isoformat(),
            'cycle': self.cycle_count,
            'status': 'completed'
        }
        
        print("✅ Cycle complete")
    
    def run_continuous(self):
        """Run continuous orchestration with CEO integration"""
        print("🚀 Starting Enhanced Live Orchestrator with CEO Integration")
        print("🏰 CEO-Approved Autonomous Deployment Active")
        print("=" * 60)
        
        while True:
            try:
                self.run_cycle()
                
                # Wait 30 minutes between cycles
                wait_time = 1800  # 30 minutes
                print(f"⏰ Waiting {wait_time//60} minutes until next cycle...")
                time.sleep(wait_time)
                
            except KeyboardInterrupt:
                print("\n🛑 Orchestrator stopped by user")
                break
            except Exception as e:
                print(f"❌ Cycle error: {e}")
                time.sleep(300)  # Wait 5 minutes on error

if __name__ == "__main__":
    orchestrator = LiveOrchestratorEnhanced()
    orchestrator.run_continuous()
